<?php

namespace app\models;

use Yii;
use yii\base\Model;

use yii\db\Connection;
use yii\db\Query;

class InsertForm extends Model
{
    public $username;
	public $insert_units;
	public $flag_message;
	public $id_user;

	public $returned;
	public $query;
   
    public function rules()
    {
        return [
            // name, email, subject and body are required
            [['username'], 'required'],
            // email has to be a valid email address
            //['email'],
	    //[['lender'], 'boolean'],
	    [['insert_units'], 'integer', 'min'=>0.01],
            
        ];
    }

	
	public function insertUnits()
	{	
		//$date = date('Y-m-d H:i:s');
		
		//1. Insert units
		$customer = new user_information();

		$connection = \Yii::$app->db;

		$this->username = strtoupper($this->username);

		//Find username ID		
		$query = new Query;
  		$query->select('user_id')
      		      ->from('user_information')
                      ->where(['like', 'user_name', '%'.$this->username.'%', false]);

  		$command = $query->createCommand();
  		$this->id_user = $command->queryScalar(); 


		if($this->id_user)
		{
			$command = $connection->createCommand("SELECT user_units_returned
							 	 FROM user_information
							    	   WHERE user_id = :_id_user");

			$command->bindParam(':_id_user',$this->id_user);
			$this->returned = $command->queryScalar();
			$command->execute();

			$this->returned = $this->returned + $this->insert_units;

			//Need to be casting to int in order to use the function findOne			
			$this->id_user = (int)$this->id_user;
			$customer = user_information::findOne($this->id_user);
			$customer->user_units_returned = $this->returned;
			$customer->save();

			$command = $connection->createCommand('call Prorate(:_insert_units)');
			$command->bindParam(':_insert_units',$this->insert_units);
			$command->execute();

			$command = $connection->createCommand('call SetNumProrates()');
			$command->execute();

			$command = $connection->createCommand('call InsertProcess()');
			$command->execute();

			$command = $connection->createCommand('call UpdateBorrowerAccount(:_id_user)');
			$command->bindParam(':_id_user',$this->id_user);
			$command->execute();
		
		
			$this->flag_message = 'Success';		
		}
		else
			$this->flag_message = 'That username is not registered';
		
		
	}//end function
	
	
}//end class

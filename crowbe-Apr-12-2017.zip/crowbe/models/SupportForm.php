<?php

namespace app\models;

use Yii;
use yii\base\Model;

use yii\db\Connection;

/**
 * ContactForm is the model behind the contact form.
 */
class SupportForm extends Model
{
    	
	
	
}//end classd

<?php

namespace app\models;

use Yii;
use yii\base\Model;

use yii\db\Connection;


class BorrowerForm extends Model
{
    public $username;
	public $borrower_units;
	public $lender_limit_profits;
       
	public $id_user;
	public $lower;
	public $weight;
	public $units_ready;
	public $available_units;
	public $flag_message;
	public $can_borrow;
	public $safety_units;
	public $can_borrow_now;
	public $borrower_flag;

   
    public function rules()
    {
        return [
            // name, email, subject and body are required
            [['username'], 'required'],
            // email has to be a valid email address
            //['email'],
	    //[['lender'], 'boolean'],
	    [['borrower_units'], 'integer', 'min'=>0.01],
         
        ];
    }

   		
	public function insertBorrower()
	{	
		
		$connection = \Yii::$app->db;
		
		//check if there is profit to set user_active = 0
		$command = $connection->createCommand('call FindUserProfit()');
		$command->execute();
		
		$command = $connection->createCommand('call SetToZeroUnitsAvailable()');
		$command->execute();
		
		//check user_available_units > 0
		//$command = $connection->createCommand('call UnitsCanBorrow()');
		//$command->execute();

		//Calculate units to borrow
		$command = $connection->createCommand('call UnitsAvailableToBorrow2()');	
		$command->execute();
													
		$command = $connection->createCommand('SELECT SUM(user_available_units) 
							  FROM user_information 
								WHERE user_is_borrower = 0 
									AND user_active = 1');
		$this->can_borrow_now = $command->queryScalar();
		$command->execute();
		
		//Delta = 3 proration safety interval 
		$this->borrower_flag = $this->borrower_units + 3;
				
		if ($this->borrower_flag < $this->can_borrow_now)
		{
			//$date = date('Y-m-d H:i:s');
		
			//1. Insert lender information
			$customer = new user_information();
			$id_user = $customer->user_id;
			$customer->user_name = strtoupper($this->username);
			$customer->user_is_borrower = 1;
			$customer->user_active = 1;
			$customer->user_units_borrowed = $this->borrower_units;
			$customer->user_statement_of_account = ($this->borrower_units)*-1;
			$customer->user_units_returned = 0;
		
			$customer->save();			
			
			$command = $connection->createCommand('call Prorate(:_units_borrow)');
			$command->bindParam(':_units_borrow',$this->borrower_units);
			$command->execute();
			
			//SetNumProrates() also add a proration to cb_prorates from cb_information.
			$command = $connection->createCommand('call SetNumProrates()');
			$command->execute();
			$command = $connection->createCommand('call UpdateLenderStatementAccount()');
			$command->execute();
			
			$this->flag_message = 'Success';
				
			//Calculate units to borrow
			$command = $connection->createCommand('call UnitsAvailableToBorrow2()');	
			$command->execute();
			   
			$command = $connection->createCommand('SELECT SUM(user_available_units) 
								 FROM user_information 
								   WHERE user_is_borrower = 0 
									AND user_active = 1');

			 $this->can_borrow_now = $command->queryScalar();
			 $command->execute();
			 
			 //Delta = 3 proration safety interval 
			 $this->can_borrow_now  = $this->can_borrow_now - 3;
		
		}
		else
		{
			$this->flag_message = 'Not enough units to borrow or not enough units to prorate';
		}
	
		
	}
	
	
}//end class

<?php

namespace app\models;

use Yii;
use yii\base\Model;

use yii\db\Connection;

/**
 * ContactForm is the model behind the contact form.
 */
class WithdrawForm extends Model
{
    	
	
	
}//end class

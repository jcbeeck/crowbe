<?php

/* @var $this yii\web\View */
use yii\helpers\Html;
use yii\widgets\LinkPager;

$this->title = 'Crowbe Prototype 1.0';
?>
<div class="site-index">

<table width="100%">
<tbody>
<tr>
<td>
<h1><strong>Crowbe Logo</strong></h1>
<p>&nbsp;</p>
<h2><strong>Crowdfunding micro-loans to the world's poor!</strong></h2>
<p>Crowbe is an environment for micro loans where the benefits and risks are shared in a community through prorations based on the weight of the lender.</p>
<p>We see Bitcoin as a universal currency, we want to capture lenders from the first world and distribute micro loans to poor women entrepreneurs (i.e in Kenya) through mobile-banking. The benefits of Crowbe: we will charge small fees, our competitors are informal predatory lenders that offer loans at exorbitant rates.</p>
<p>&nbsp;</p>
<h3>Useful links:</h3>
<p><a class="btn btn-default" href="http://www.crowbe.com/crowbe.pdf">Crowbe White paper &raquo;</a></p>
<p><a class="btn btn-default" href="http://www.crowbe.com/pitch.pdf">Crowbe Pitch &raquo;</a></p>
<p><a class="btn btn-default" href="http://pt.slideshare.net/janbeeck/crowbe">Crowbe PPT &raquo;</a></p>
<p><a class="btn btn-default" href="https://github.com/jcbeeck/crowbe">Source code &raquo;</a>(prototype 0.1)</p>
</td>
<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</td>
<td>

<p>&nbsp;</p>
<h3><strong>Instructions:</strong></h3>
<p> </p>
<p>If you are a lender go and make your investment in the fiat currency of your choice on the page <strong>Lender</strong>.</p>
<p>If you want to apply to a loan go to the page <strong>Borrower</strong>.</p>
<p>If you are going to return money go to the page <strong>Return</strong>.</p>
<p>If you want to withdraw money go to the page <strong>Withdraw</strong>.</p>
<p>You can see the information on the page <strong>Ledger</strong>.</p>
<p>&nbsp;</p>
<h3><strong>Currently information:</strong></h3>
<li><label>Total prorates</label>: <?= Html::encode($model->prorates) ?></li>
<li><label>Available units</label>: <?= Html::encode($model->can_borrow_now) ?></li>
<li><label>Obligations</label>: xxx</li>
</td>
</tr>
</tbody>
</table>

</div>

<?php

namespace app\models;

use Yii;
use yii\base\Model;

use yii\db\Connection;
use yii\db\Query;

class IndexForm extends Model
{
    	public $prorates;
        public $cb_id;
        public $can_borrow_now;
	
	public function updateInformation()
	{	
		
		$connection = \Yii::$app->db;

		$command = $connection->createCommand('SELECT cb_id FROM cb_information ORDER BY cb_id DESC limit 1');
		$this->cb_id = $command->queryScalar();
		$command->execute();

		$command = $connection->createCommand('SELECT cb_prorates FROM cb_information WHERE cb_id = :_cbid');
		$command->bindParam(':_cbid',$this->cb_id);
		$this->prorates = $command->queryScalar();
		$command->execute();

		$command = $connection->createCommand('SELECT SUM(user_available_units) 
							  FROM user_information 
								WHERE user_is_borrower = 0 
									AND user_active = 1');
						
        //Delta = 3 proration safety interval 						
		$this->can_borrow_now = round($command->queryScalar(),2);
		$command->execute();
		$this->can_borrow_now = $this->can_borrow_now - 3;

		
	}//end function
	
	
}//end class

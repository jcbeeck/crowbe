<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;

use app\models\LenderForm;
use app\models\BorrowerForm;
use app\models\InsertForm;
use app\models\WithdrawForm;
use app\models\SupportForm;
use app\models\IndexForm;

use yii\data\Pagination;

//table
use app\models\user_information;
use yii\web\HttpException;
use yii\db\Connection;

class SiteController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    public function actionIndex()
    {
        //return $this->render('index');

	$model = new IndexForm();
        $model->updateInformation();
	
	return $this->render('index', ['model' => $model,]);
	
    }

    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    public function actionContact()
    {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('contact', [
            'model' => $model,
        ]);
    }

    public function actionAbout()
    {
        return $this->render('about');
    }

    public function actionLender()
    {
	$model = new LenderForm();
	
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            //Yii::$app->session->setFlash('feedbackFormSubmitted');
		$model->insertLender();
            return $this->render('lender', ['model' => $model]);
        } else {
            return $this->render('lender', [
                'model' => $model,
            ]);
        }
	
    }// end function

    public function actionBorrower()
    {
         $model = new BorrowerForm();
	
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            //Yii::$app->session->setFlash('feedbackFormSubmitted');
		$model->insertBorrower();
				//$model->extractLender();
            return $this->render('borrower', ['model' => $model]);
        } else {
            return $this->render('borrower', [
                'model' => $model,
            ]);
        }
	
    }// end function

    public function actionInsert()
    {
         $model = new InsertForm();
	
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            //Yii::$app->session->setFlash('feedbackFormSubmitted');
			$model->insertUnits();
				//$model->extractLender();
            return $this->render('insert', ['model' => $model]);
        } else {
            return $this->render('insert', [
                'model' => $model,
            ]);
        }
	
    }// end function

    public function actionWithdraw()
    {
	$model = new WithdrawForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('withdraw', [
            'model' => $model,
        ]);
        
    }// end function 	
    

    public function actionLedger()
    {
        $query = user_information::find();

        $pagination = new Pagination([
            'defaultPageSize' => 10,
            'totalCount' => $query->count(),
        ]);

        $persons = $query->orderBy('user_id')
            ->offset($pagination->offset)
            ->limit($pagination->limit)
            ->all();

        return $this->render('ledger', [
            'persons' => $persons,
            'pagination' => $pagination,
        ]);
    }// end function

    public function actionSupport()
    {
        return $this->render('support');
    } 	

}//end class

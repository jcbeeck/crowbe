<?php

namespace app\models;

use yii\db\ActiveRecord;

class user_information extends ActiveRecord
{
}

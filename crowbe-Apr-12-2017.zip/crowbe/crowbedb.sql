-- phpMyAdmin SQL Dump
-- version 4.0.10.12
-- http://www.phpmyadmin.net
--
-- Host: 127.9.153.130:3306
-- Generation Time: May 13, 2016 at 07:10 AM
-- Server version: 5.5.45
-- PHP Version: 5.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `crowbedb`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `CalculateLowerLimit`(IN `id` INT)
BEGIN

	DECLARE invested DOUBLE;
	DECLARE cal_lower_limit DOUBLE;
	DECLARE lower_limit DOUBLE;

	SET	invested = (SELECT user_units_invested FROM user_information WHERE user_id=id);
	SET cal_lower_limit = ((invested * 2.9)/100)+0.30;
	SET lower_limit = invested + cal_lower_limit;
	UPDATE user_information SET user_lower_limit_profit = lower_limit WHERE user_id=id;

END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `CalculateWeight`()
BEGIN

	DECLARE id INT;
	DECLARE account_statement DOUBLE;
	DECLARE weight INT;
	DECLARE i INT;
	DECLARE num_lenders INT;

	DECLARE user_weight_cursor CURSOR FOR
		SELECT user_id, user_statement_of_account, user_weight 
			FROM user_information 
				WHERE user_is_borrower = 0 AND user_active = 1
					ORDER BY user_statement_of_account DESC;

	SET num_lenders = (SELECT COUNT(*) FROM user_information 
							WHERE user_is_borrower = 0 AND user_active = 1);

	SET i = 1;

	OPEN user_weight_cursor;

	fill_weights: LOOP
		
		FETCH user_weight_cursor INTO id, account_statement, weight;
		
			SET weight = i;
			UPDATE user_information SET user_weight = weight WHERE user_id = id;
			SET i = i + 1;
			IF i > num_lenders THEN
				LEAVE fill_weights;
			END IF;
     
		END LOOP fill_weights;
	CLOSE user_weight_cursor;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `FillAllUsersProfitTable`()
BEGIN

	INSERT INTO cb_profit(cb_profit_id, cb_profit_username, cb_profit_invested, 
						  cb_profit_lowerprofit, cb_profit_total)
		SELECT user_id, user_name, user_units_invested, 
			   user_lower_limit_profit, user_total_profit
			FROM user_information
				WHERE user_is_borrower = 0;
END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `FillLowerLimit`()
BEGIN
	
	DECLARE num_users INT;
	DECLARE i INT;
	
	SET i = 1;
	WHILE i <= 15 DO
		CALL CalculateLowerLimit(i);
		SET i = i + 1;
	END WHILE;

END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `FillProfitTable`()
BEGIN

	INSERT INTO cb_profit(cb_profit_id, cb_profit_username, cb_profit_invested, 
						  cb_profit_lowerprofit, cb_profit_total)
		SELECT user_id, user_name, user_units_invested, 
			   user_lower_limit_profit, user_total_profit
			FROM user_information
				WHERE user_is_borrower = 0
					AND user_active = 0;

END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `FindUserProfit`()
proc:BEGIN
	DECLARE num_lenders INT;
	DECLARE total_profit DOUBLE;
	DECLARE statement DOUBLE;
	DECLARE invested DOUBLE;
	DECLARE id INT;
	DECLARE i INT;

	DECLARE user_profit_cursor CURSOR FOR
		SELECT user_id, user_statement_of_account, user_units_invested  
			FROM user_information 
				WHERE user_is_borrower = 0 AND user_active = 1
					AND user_statement_of_account > user_lower_limit_profit;

	SET num_lenders = (SELECT COUNT(*) FROM user_information 
					WHERE user_is_borrower = 0 AND user_active = 1
						AND user_statement_of_account > user_lower_limit_profit);

	IF num_lenders = 0 THEN
        LEAVE proc;
    END IF;

	SET i = 1;

	OPEN user_profit_cursor;
	
	profit: LOOP
	
		FETCH user_profit_cursor INTO id,statement,invested;

			SET total_profit = statement - invested;
			UPDATE user_information SET user_total_profit = total_profit WHERE user_id=id;
			UPDATE user_information SET user_active = 0 WHERE user_id=id;
			SET i = i + 1;
			IF i > num_lenders THEN
				LEAVE profit;
			END IF;

		END LOOP profit;
	
    CLOSE user_profit_cursor;

END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `InsertProcess`()
BEGIN
	DECLARE num_lenders INT;
	DECLARE units_to_insert DOUBLE;
	DECLARE statement DOUBLE;
	DECLARE pivot DOUBLE;
	DECLARE id INT;
	DECLARE i INT;

	DECLARE units_insert_borrow_cursor CURSOR FOR
		SELECT user_id, user_statement_of_account, user_prorate_pivot  
			FROM user_information 
				WHERE user_is_borrower = 0 AND user_active = 1
					AND user_statement_of_account < user_lower_limit_profit;

	SET num_lenders = (SELECT COUNT(*) FROM user_information 
							WHERE user_is_borrower = 0 AND user_active = 1
								AND user_statement_of_account < user_lower_limit_profit);

	SET i = 1;
	
	OPEN units_insert_borrow_cursor;
	
	get_units_insert_borrow: LOOP
	
		FETCH units_insert_borrow_cursor INTO id,statement,pivot;

			SET units_to_insert = statement + pivot;
			UPDATE user_information SET user_statement_of_account = units_to_insert WHERE user_id=id;
			SET i = i + 1;
			IF i = num_lenders THEN
				LEAVE get_units_insert_borrow;
			END IF;

		END LOOP get_units_insert_borrow;
	
    CLOSE units_insert_borrow_cursor;

END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `log_msg`(IN `msg` VARCHAR(255))
BEGIN
	INSERT INTO logtable SELECT 0, msg;
END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `Prorate`(IN `input` DOUBLE)
BEGIN

	DECLARE id INT;
	DECLARE ready_to_borrow DOUBLE;
	DECLARE weight INT;
	DECLARE num_lenders INT;
	DECLARE i INT;
	DECLARE j INT;
	DECLARE acum INT;
	DECLARE w DOUBLE;
	DECLARE x DOUBLE;
	DECLARE y DOUBLE;
	DECLARE z DOUBLE;
	DECLARE prorate DOUBLE;
	DECLARE units_input DOUBLE;
	DECLARE pivot DOUBLE;
	DECLARE num INT;
	DECLARE new_units_to_borrow DOUBLE;

	DECLARE prorate_cursor CURSOR FOR
		SELECT user_id, user_available_units, user_weight, user_prorate_pivot
			FROM user_information 
				WHERE user_is_borrower = 0 AND user_active = 1 AND user_available_units > 0
					ORDER BY user_weight ASC;

	SET num_lenders = (SELECT COUNT(*)
				FROM user_information 
					WHERE user_is_borrower = 0 AND user_active = 1
						ORDER BY user_weight ASC);

	CREATE TEMPORARY TABLE pivots_array(
		pos INT NOT NULL DEFAULT 0,
		pivot_element DOUBLE NOT NULL DEFAULT 0);

	SET units_input = input;
	# in the position 1 goes the units input
	INSERT INTO pivots_array (pos, pivot_element) VALUES (0,units_input);
	 
	SET i = 0;
    SET j = 0;
	SET acum = 0;
	
	OPEN prorate_cursor;
	
	WHILE i < num_lenders DO
		FETCH prorate_cursor INTO id, ready_to_borrow, weight, pivot;
	
			SET w = ((SELECT pivot_element FROM pivots_array WHERE pos = i) / (num_lenders - i));
			SET x = w * (num_lenders - j);
			SET y = x / (num_lenders - i);
			SET prorate = w + y;
			UPDATE user_information SET user_prorate_pivot = prorate WHERE user_id = id;
			SET new_units_to_borrow = (SELECT user_statement_of_account
						FROM user_information
						 WHERE user_is_borrower = 0 AND user_active = 1 AND user_id = id) - prorate; 
			UPDATE user_information SET user_units_ready_to_borrow = new_units_to_borrow WHERE user_id = id;
			SET acum = prorate + acum;
			SET z = units_input - acum;
			SET i = i + 1;
			SET j = j + 1;
			INSERT INTO pivots_array (pos, pivot_element) VALUES (i,z);

		END WHILE;
	
	CLOSE prorate_cursor;

	DROP TABLE pivots_array;

END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `SetCBProrates`(IN `input` INT)
BEGIN
	DECLARE num_prorates INT;

	SET num_prorates = (SELECT cb_prorates 
							FROM cb_information
								WHERE cb_id = input - 1);

	IF num_prorates IS NOT NULL THEN
		UPDATE cb_information SET cb_prorates = num_prorates + 1 WHERE cb_id = input;
	END IF;

	
END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `SetFirstLendersStatementAccount`()
BEGIN
	DECLARE invested DOUBLE;
	DECLARE account_statement DOUBLE;
	DECLARE id INT;

	DECLARE user_statement_cursor CURSOR FOR
		SELECT user_id, user_units_invested, user_statement_of_account
					FROM user_information 
						WHERE user_is_borrower = 0 AND user_active = 1;

	OPEN user_statement_cursor;
	
	first_statement: LOOP
		FETCH user_statement_cursor INTO id, invested, account_statement;
		
			UPDATE user_information SET user_statement_of_account = invested WHERE user_id = id;
	
		END LOOP first_statement;

	CLOSE user_statement_cursor;
	
END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `SetNumProrates`()
BEGIN
	DECLARE id INT;
	DECLARE num_prorates INT;
	DECLARE i INT;
	DECLARE num_lenders INT;

	DECLARE cbid INT;
	DECLARE prorates INT;

	DECLARE prorate_cursor CURSOR FOR
		SELECT user_id, user_num_prorated 
			FROM user_information 
				WHERE user_is_borrower = 0 AND user_active = 1;

	SET i = 1;

	SET num_lenders = (SELECT COUNT(*) FROM user_information 
							WHERE user_is_borrower = 0 AND user_active = 1);

	SET cbid = (SELECT cb_id FROM cb_information ORDER BY cb_id DESC limit 1);

    SET prorates = (SELECT cb_prorates FROM cb_information WHERE cb_id = cbid);
	
	OPEN prorate_cursor;
	
	get_prorate: LOOP
	
		FETCH prorate_cursor INTO id, num_prorates;
			IF num_prorates IS NULL THEN
				UPDATE user_information SET user_num_prorated = 1 WHERE user_id=id;
				SET i = i + 1;
			END IF;
			
			IF num_prorates IS NOT NULL THEN
				UPDATE user_information SET user_num_prorated = num_prorates + 1 WHERE user_id=id;
				SET i = i + 1;
			END IF;

			IF i > num_lenders THEN
				LEAVE get_prorate;
			END IF;

		END LOOP get_prorate;
	
    CLOSE prorate_cursor;

	UPDATE cb_information SET cb_prorates = prorates + 1 WHERE cb_id = cbid;
END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `SetProratePivot`()
BEGIN

	DECLARE id INT;
	DECLARE i INT;
	DECLARE num_lenders INT;

	DECLARE pivot_cursor CURSOR FOR
		SELECT user_id
			FROM user_information 
				WHERE user_is_borrower = 0 AND user_active = 1;

	SET num_lenders = (SELECT COUNT(*) FROM user_information 
							WHERE user_is_borrower = 0 AND user_active = 1);

	SET i = 1;

	OPEN pivot_cursor;
	
	get_units_for_pivot: LOOP
	
		FETCH pivot_cursor INTO id;

			UPDATE user_information SET user_prorate_pivot = 0 WHERE user_id=id;
			SET i = i + 1;
			IF i = num_lenders THEN
				LEAVE get_units_for_pivot;
			END IF;
			
		END LOOP get_units_for_pivot;
	
    CLOSE pivot_cursor;

END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `SetProrateZero`()
BEGIN
	DECLARE id INT;
	DECLARE prorate INT;

	DECLARE prorate_cursor CURSOR FOR
		SELECT user_id, prorate
			FROM user_information 
				WHERE user_is_borrower = 0 AND user_active = 1;

	OPEN prorate_cursor;
	
	_prorate: LOOP
			
		FETCH prorate_cursor INTO id, prorate;
		
			UPDATE user_information SET user_num_prorated = 0
				WHERE user_id = id;

		END LOOP _prorate;
	
	CLOSE prorate_cursor;

END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `SetReturnedUnits`(IN `id` INT, IN `units` DOUBLE)
BEGIN

	DECLARE returned DOUBLE;
	DECLARE returned2 DOUBLE;
	
	SET returned = (SELECT user_units_returned
			 FROM user_information
			   WHERE user_id=id);

	IF returned IS NULL THEN 
		UPDATE user_information SET user_units_returned = units WHERE user_id=id;
	
	ELSE 
		SET returned2 = returned + units;
		UPDATE user_information SET user_units_returned = returned2 WHERE user_id=id;	
		
END IF;	

END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `SetToZeroUnitsAvailable`()
BEGIN
	DECLARE id INT;
    DECLARE available DOUBLE;
    DECLARE i INT;
	DECLARE num_lenders INT;

	DECLARE prorate_cursor CURSOR FOR
		SELECT user_id, user_available_units
			FROM user_information 
				WHERE user_is_borrower = 0 AND user_active = 1;
				
	SET num_lenders = (SELECT COUNT(*) FROM user_information 
							WHERE user_is_borrower = 0 AND user_active = 1);

	SET i = 1;

	OPEN prorate_cursor;
	
	_prorate: LOOP
			
		FETCH prorate_cursor INTO id, available;
		
			UPDATE user_information SET user_available_units = 0
				WHERE user_id = id;
				
			SET i = i + 1;
				IF i > num_lenders THEN
					LEAVE _prorate;
			END IF;

		END LOOP _prorate;
	
	CLOSE prorate_cursor;

END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `UnitsAvailableToBorrow`(IN `id` INT)
BEGIN
	DECLARE available_units DOUBLE;
	DECLARE num_lenders INT;
	DECLARE units_to_borrow DOUBLE;
				
	SET available_units = (SELECT user_statement_of_account FROM user_information
								WHERE user_is_borrower = 0 AND user_active = 1 AND user_id=id);

	SET num_lenders = (SELECT COUNT(*) FROM user_information 
							WHERE user_is_borrower = 0 AND user_active = 1
								AND user_available_units > 0
								OR user_available_units IS NULL);
							
	SET units_to_borrow = available_units / num_lenders;
	
	UPDATE user_information SET user_available_units = units_to_borrow WHERE user_id=id;

END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `UnitsAvailableToBorrow2`()
BEGIN
	DECLARE available_units DOUBLE;
	DECLARE num_lenders INT;
	DECLARE units_to_borrow DOUBLE;
	DECLARE id INT;
	DECLARE i INT;

	DECLARE units_for_borrow_cursor CURSOR FOR
		SELECT user_id, user_statement_of_account  
			FROM user_information 
				WHERE user_is_borrower = 0 AND user_active = 1;

	SET num_lenders = (SELECT COUNT(*) FROM user_information 
							WHERE user_is_borrower = 0 AND user_active = 1);

	SET i = 1;
	
	OPEN units_for_borrow_cursor;
	
	get_units_for_borrow: LOOP
	
		FETCH units_for_borrow_cursor INTO id,available_units;

			SET units_to_borrow = available_units / num_lenders;
			UPDATE user_information SET user_available_units = units_to_borrow WHERE user_id=id;
			UPDATE user_information SET user_units_ready_to_borrow = units_to_borrow WHERE user_id=id;
			SET i = i + 1;
			IF i > num_lenders THEN
				LEAVE get_units_for_borrow;
			END IF;
			
		END LOOP get_units_for_borrow;
	
    CLOSE units_for_borrow_cursor;

END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `UnitsCanBorrow`()
BEGIN
	DECLARE available_units DOUBLE;
	DECLARE num_lenders INT;
	DECLARE units_to_borrow DOUBLE;
	DECLARE id INT;
	DECLARE i INT;

	DECLARE units_for_borrow_cursor CURSOR FOR
		SELECT user_id, user_statement_of_account  
			FROM user_information 
				WHERE user_is_borrower = 0 
					AND user_active = 1 
					AND user_statement_of_account > 0;

	SET num_lenders = (SELECT COUNT(*) FROM user_information 
							WHERE user_is_borrower = 0 AND user_active = 1
								AND user_available_units > 0);

	SET i = 1;
	
	OPEN units_for_borrow_cursor;
	
	get_units_can_borrow: LOOP
	
		FETCH units_for_borrow_cursor INTO id,available_units;

			SET units_to_borrow = available_units / num_lenders;
			UPDATE user_information SET user_available_units = units_to_borrow WHERE user_id=id;
			SET i = i + 1;
			IF i > num_lenders THEN
				LEAVE get_units_can_borrow;
			END IF;

		END LOOP get_units_can_borrow;
	
    CLOSE units_for_borrow_cursor;
END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `UpdateBorrowerAccount`(IN `id` INT)
BEGIN

	DECLARE account DOUBLE;
	DECLARE returned DOUBLE;
        DECLARE account2 DOUBLE;
	
	SET account = (SELECT user_statement_of_account
			         FROM user_information
			           WHERE user_id=id);

	SET returned = (SELECT user_units_returned
			         FROM user_information
			          WHERE user_id=id);

	SET account2 = account + returned;
	UPDATE user_information SET user_statement_of_account = account2 WHERE user_id=id;


END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `UpdateLenderStatementAccount`()
BEGIN
	DECLARE id INT;
	DECLARE account_statement DOUBLE;
	DECLARE to_borrow DOUBLE;
	DECLARE i INT;
	DECLARE num_lenders INT;

	DECLARE user_update_statement_cursor CURSOR FOR
		SELECT user_id, user_statement_of_account, user_prorate_pivot
			FROM user_information 
				WHERE user_is_borrower = 0 AND user_active = 1;

	SET num_lenders = (SELECT COUNT(*) FROM user_information 
							WHERE user_is_borrower = 0 AND user_active = 1);

	SET i = 1;

	OPEN user_update_statement_cursor;
	
	statement: LOOP
			
		FETCH user_update_statement_cursor INTO id, account_statement, to_borrow;
		
			UPDATE user_information SET user_statement_of_account = user_statement_of_account - to_borrow
				WHERE user_id = id;

			IF ((SELECT user_available_units 
					FROM user_information
						WHERE user_id = id) - to_borrow) < 0 THEN
				UPDATE user_information SET user_available_units = 0 WHERE user_id = id;
			ELSE
				UPDATE user_information SET user_available_units = user_available_units - to_borrow
					WHERE user_id = id;

			END IF;

			SET i = i + 1;
			IF i = num_lenders THEN
				LEAVE statement;
			END IF;

		END LOOP statement;
	
	CLOSE user_update_statement_cursor;

END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `UpdateLenderStatementAccount3`(IN `id` INT)
BEGIN
	DECLARE id INT;
	DECLARE account_statement DOUBLE;
	DECLARE units_available DOUBLE;

	SET account_statement = (SELECT user_statement_of_account FROM user_information
								WHERE user_is_borrower = 0 AND user_active = 1 AND user_id=id);

	SET units_available = (SELECT user_available_units FROM user_information
								WHERE user_is_borrower = 0 AND user_active = 1 AND user_id=id);

	UPDATE user_information SET user_statement_of_account = account_statement - units_available WHERE user_id=id;

END$$

CREATE DEFINER=`adminCNemvDK`@`127.9.153.130` PROCEDURE `UpdateNumProratedLenders`()
BEGIN
	
	DECLARE num_prorated INT;
	DECLARE new_prorated INT;
	DECLARE id INT;

	DECLARE user_update_prorated_cursor CURSOR FOR
		SELECT user_id, user_num_prorated
			FROM user_information 
				WHERE user_is_borrower = 0 AND user_active = 1;

	OPEN user_update_prorated_cursor;

	prorated: LOOP
	
		FETCH user_update_prorated_cursor INTO id, num_prorated;
			
			SET new_prorated = num_prorated + 1;
			UPDATE user_information SET user_num_prorated = new_prorated WHERE user_id = id;

		END LOOP prorated;
	
	CLOSE user_update_prorated_cursor;

END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `AvailableUnits`() RETURNS double
BEGIN
	DECLARE total_available DOUBLE;

	SET total_available = (SELECT SUM(user_divided) FROM user_information 
								WHERE user_is_borrower = 0 AND user_active = 1);

RETURN total_available;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `cb_information`
--

CREATE TABLE IF NOT EXISTS `cb_information` (
  `cb_id` int(11) NOT NULL AUTO_INCREMENT,
  `cb_units_for_borrow` double DEFAULT NULL,
  `cb_safety_units` double DEFAULT NULL,
  `cb_prorates` int(11) DEFAULT NULL,
  PRIMARY KEY (`cb_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `cb_information`
--

INSERT INTO `cb_information` (`cb_id`, `cb_units_for_borrow`, `cb_safety_units`, `cb_prorates`) VALUES
(42, 0, 0, 3);

-- --------------------------------------------------------

--
-- Table structure for table `cb_profit`
--

CREATE TABLE IF NOT EXISTS `cb_profit` (
  `cb_profit_id` int(11) NOT NULL,
  `cb_profit_username` varchar(45) DEFAULT NULL,
  `cb_profit_invested` double DEFAULT NULL,
  `cb_profit_lowerprofit` double DEFAULT NULL,
  `cb_profit_total` double DEFAULT NULL,
  PRIMARY KEY (`cb_profit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cb_profit`
--

INSERT INTO `cb_profit` (`cb_profit_id`, `cb_profit_username`, `cb_profit_invested`, `cb_profit_lowerprofit`, `cb_profit_total`) VALUES
(236, 'lender1', 50, 51.75, 2.5),
(237, 'lender2', 30, 31.17, 2.6666666666666643),
(238, 'lender3', 10, 10.59, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cb_user_contact`
--

CREATE TABLE IF NOT EXISTS `cb_user_contact` (
  `cb_user_contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `cb_user_contact_name` varchar(45) DEFAULT NULL,
  `cb_user_contact_email` varchar(45) DEFAULT NULL,
  `cb_user_contact_subject` varchar(45) DEFAULT NULL,
  `cb_user_contact_body` varchar(3000) DEFAULT NULL,
  `cb_user_contact_create_time` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`cb_user_contact_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `cb_user_contact`
--

INSERT INTO `cb_user_contact` (`cb_user_contact_id`, `cb_user_contact_name`, `cb_user_contact_email`, `cb_user_contact_subject`, `cb_user_contact_body`, `cb_user_contact_create_time`) VALUES
(1, 'Jan Beeck', 'jcbeeck@gmail.com', 'I would like to make business with you', 'This paradigm is amaizing, I would like to invest a lot of money in the app, my email is bill.gates@hotmail.com', '2014-09-03 01:30:55'),
(2, 'Michelle Beeck', 'michi@gmail.com', 'Me gusta', 'Me gusta mucho esta app, cómo puedo invertir?', '2014-09-03 01:34:34'),
(3, 'Alana Breen', 'breen@gmail.com', 'Whats up?', 'what''s up? testing this amaizing app', '2014-09-03 06:05:02');

-- --------------------------------------------------------

--
-- Table structure for table `cb_user_feedback`
--

CREATE TABLE IF NOT EXISTS `cb_user_feedback` (
  `cb_user_feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `cb_user_feedback_name` varchar(45) NOT NULL,
  `cb_user_feedback_email` varchar(45) NOT NULL,
  `cb_user_feedback_text` varchar(3000) NOT NULL,
  `cb_user_feedback_create_time` varchar(20) NOT NULL,
  PRIMARY KEY (`cb_user_feedback_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `cb_user_feedback`
--

INSERT INTO `cb_user_feedback` (`cb_user_feedback_id`, `cb_user_feedback_name`, `cb_user_feedback_email`, `cb_user_feedback_text`, `cb_user_feedback_create_time`) VALUES
(1, 'Lang', '', 'Great idea!  Bitcoin link could be a problem for two reasons:  1) Spectacular failure of Mt Gox\r\n2) volatility of Bitcoin \r\nSo as soon as you start talking about wallets and bitcoin... that doesn''t give the nice, secure feeling you want a bank to have', '2015-01-30 18:20:43'),
(2, 'Jan', '', 'Bitcoins is volatility as many currencies, its real utility is to be a "universal currency", and no need of a third party for transactions.', '2015-02-09 22:38:28'),
(3, 'Jan', '', 'The convenience of having digital wallets is that they can be accessible from cell phones, the former is already penetrated in poor and rural areas.', '2015-02-21 21:30:13'),
(4, 'Jan', '', 'One of the challenges is to have bitcoin "exchange houses" to local currencies in poor countries. Considering that digital wallets are accessible from cellphones and these are already quite widespread.', '2015-02-23 23:31:22'),
(5, 'Jan', '', 'One solution for the bitcoin "exchange houses" could be through Banks'' ATMs:>> "Once you send your bitcoin to our address, you’ll receive a text message with a code and with that code you can go to any ATM and receive cash right away," co-founder and COO Alex Lopera explained, adding that customers don''t need to have a credit card or account with the banks in order to receive cash (ref:http://www.coindesk.com/btcpoint-spanish-bank-network-bitcoin-atms/).', '2015-03-07 19:11:51');

-- --------------------------------------------------------

--
-- Table structure for table `logtable`
--

CREATE TABLE IF NOT EXISTS `logtable` (
  `id` int(11) NOT NULL DEFAULT '0',
  `log` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `logtable`
--

INSERT INTO `logtable` (`id`, `log`) VALUES
(0, 'prorate is: 6 and id is: 1 and i is: 0');

-- --------------------------------------------------------

--
-- Table structure for table `prorate_test`
--

CREATE TABLE IF NOT EXISTS `prorate_test` (
  `prorate_test_id` int(11) NOT NULL AUTO_INCREMENT,
  `prorate_test_element` double DEFAULT NULL,
  PRIMARY KEY (`prorate_test_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `prorate_test`
--

INSERT INTO `prorate_test` (`prorate_test_id`, `prorate_test_element`) VALUES
(1, 10),
(2, 8.333333333333334),
(3, 6.8),
(4, 5),
(5, 3.3333333333333335),
(6, 2),
(7, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_information`
--

CREATE TABLE IF NOT EXISTS `user_information` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) DEFAULT NULL,
  `user_is_borrower` int(11) DEFAULT NULL,
  `user_units_borrowed` double DEFAULT NULL,
  `user_units_invested` double DEFAULT NULL,
  `user_lower_limit_profit` double DEFAULT NULL,
  `user_num_prorated` int(11) DEFAULT NULL,
  `user_total_profit` double DEFAULT NULL,
  `user_active` int(11) DEFAULT NULL,
  `user_units_ready_to_borrow` double DEFAULT NULL,
  `user_weight` int(11) DEFAULT NULL,
  `user_prorate_pivot` double DEFAULT NULL,
  `user_statement_of_account` double DEFAULT NULL,
  `user_available_units` double DEFAULT NULL,
  `user_units_returned` double DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=559 ;

--
-- Dumping data for table `user_information`
--

INSERT INTO `user_information` (`user_id`, `user_name`, `user_is_borrower`, `user_units_borrowed`, `user_units_invested`, `user_lower_limit_profit`, `user_num_prorated`, `user_total_profit`, `user_active`, `user_units_ready_to_borrow`, `user_weight`, `user_prorate_pivot`, `user_statement_of_account`, `user_available_units`, `user_units_returned`) VALUES
(553, 'LENDER1@YUP.COM', 0, NULL, 30, 31.17, 3, NULL, 1, 6.666666666666667, 2, 3.3333333333333335, 26.666666666666668, 6.666666666666667, NULL),
(554, 'LENDER2@HOTMAIL.COM', 0, NULL, 10, 10.59, 3, NULL, 1, 2, 3, 2, 8, 2, NULL),
(555, 'LENDER3@GMAIL.COM', 0, NULL, 50, 51.75, 3, NULL, 1, 11.25, 1, 5, 45, 11.25, NULL),
(556, 'LENDER4@GMAIL.COM', 0, NULL, 5, 5.445, 3, NULL, 1, 1.25, 4, 0, 5, 1.25, NULL),
(557, 'BORROWER1@HOTMAIL.COM', 1, 15, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, 0, NULL, 15),
(558, 'BORROWER2@YAHOO.COM', 1, 10, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, -10, NULL, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

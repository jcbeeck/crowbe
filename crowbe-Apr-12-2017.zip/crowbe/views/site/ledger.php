<?php

/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\widgets\LinkPager;

$this->title = 'Ledger';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>
	
	<p>Type 1 is borrower, Type 0 is lender. Available is the amount of units per lender that can be used for the next loan.</p>
	<style>
	table, th, td {
	    border: 1px solid black;
	    border-collapse: collapse;
	}
	th, td {
	    padding: 5px;
	}
	</style>
	<?php foreach ($persons as $user_information): ?>
	    <table style="width:100%">
		<tr>
		<th><?= Html::encode("ID") ?>:</th>
			<th><?= Html::encode("Username") ?>:</th>
			<th><?= Html::encode("Type") ?>:</th>
			<th><?= Html::encode("Account") ?>:</th>
			<th><?= Html::encode("Borrowed") ?>:</th>
			<th><?= Html::encode("Invested") ?>:</th>
			<th><?= Html::encode("MinProfit") ?>:</th>
			<th><?= Html::encode("Available") ?>:</th>
			<th><?= Html::encode("Weight") ?>:</th>
			<th><?= Html::encode("Prorates") ?>:</th>
			<th><?= Html::encode("Profit") ?>:</th> 
		 </tr>
		 <tr>
			<td><?= $user_information->user_id?></td>
			<td><?= $user_information->user_name?></td>
			<td><?= $user_information->user_is_borrower?></td>
			<td><?= $user_information->user_statement_of_account?></td>
			<td><?= $user_information->user_units_borrowed?></td>
			<td><?= $user_information->user_units_invested?></td>
			<td><?= $user_information->user_lower_limit_profit?></td>
			<td><?= $user_information->user_available_units?></td>
	 		<td><?= $user_information->user_weight?></td>
		    <td><?= $user_information->user_num_prorated?></td>
		    <td><?= $user_information->user_total_profit?></td>
	    </tr>
	<?php endforeach; ?>
	</table>

	<?= LinkPager::widget(['pagination' => $pagination]) ?>
	    
</div>




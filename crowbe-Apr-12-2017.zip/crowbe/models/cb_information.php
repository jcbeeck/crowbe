<?php

namespace app\models;

use yii\db\ActiveRecord;

class cb_information extends ActiveRecord
{
}

<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\captcha\Captcha;

/**
 * @var yii\web\View $this
 * @var yii\widgets\ActiveForm $form
 * @var app\models\ContactForm $model
 */
$this->title = 'Lender';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-contact">
    <h1><?= Html::encode($this->title) ?></h1>

    <?php if (Yii::$app->session->hasFlash('lenderFormSubmitted')): ?>

    <div class="alert alert-success">
        Thank you for contacting us. We will respond to you as soon as possible.
    </div>

    <p>
        Note that if you turn on the Yii debugger, you should be able
        to view the mail message on the mail panel of the debugger.
        <?php if (Yii::$app->mail->useFileTransport): ?>
        Because the application is in development mode, the email is not sent but saved as
        a file under <code><?= Yii::getAlias(Yii::$app->mail->fileTransportPath) ?></code>.
        Please configure the <code>useFileTransport</code> property of the <code>mail</code>
        application component to be false to enable email sending.
        <?php endif; ?>
    </p>

    <?php else: ?>

   
        <p>If you are a Lender please put your username and your micro investment (in the fiat currency of your choice).</p>

         <p>Crowbe will calculate the minimum profit of your investment, your position in the lenders' queue (Weight),
        and the units that the system will use in the next loan. Thank you.</p>
    

    <div class="grid">
        <div class="col-lg-5">
            <?php $form = ActiveForm::begin(['id' => 'lender-form']); ?>
                <?= $form->field($model, 'username') ?>
		   <div class="grid">
			<div class="col-lg-3">
				<?= $form->field($model, 'lender_units') ?> 
				<?= Html::submitButton('Submit', ['class' => 'btn btn-primary', 'name' => 'lender-button']) ?>
			</div>
					
		</div>
                <div class="form-group">
                    
                </div>
            
        </div>
		<?php ActiveForm::end(); ?>
    </div>

    <?php endif; ?>
	<ul>
    <li><label>Minimum profit</label>: <?= Html::encode($model->lower) ?></li>
	<li><label>Weight</label>: <?= Html::encode($model->weight) ?></li>
	<li><label>Units</label>: <?= Html::encode(round($model->available_units)) ?></li>
	<li><label>Lender</label>: <?= Html::encode($model->username) ?></li>
	</ul>
</div>

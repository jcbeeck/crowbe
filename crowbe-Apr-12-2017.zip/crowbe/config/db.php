<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=db_name',
    'username' => 'root',
    'password' => 'root',
    'charset' => 'utf8',
];

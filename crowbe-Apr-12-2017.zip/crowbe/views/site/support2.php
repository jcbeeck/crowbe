<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Support';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>If you want to help us to&nbsp;bootstrap&nbsp;this&nbsp;project by&nbsp;being a sponsor or want to contact us, please send an email 	to <strong>jcbeeck@gmail.com&nbsp;</strong> (Latin America) or to <strong>lehner.andi@gmail.com&nbsp;</strong> (Europe). </p>


<p>Please Donate To Bitcoin Address: <b>1E3Jb5uANU8Ya6Stz8p2C1T1xuHfGjfSpg</b></p>
<img src="http://www.crowbe.com/qr.png" alt="Address" style="width:146px;height:142px;">


</div>
